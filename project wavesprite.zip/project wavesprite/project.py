from PIL import Image
import numpy as np
import winsound
import wave
import cv2
import os
import matplotlib.pyplot as plt


def make_sound(image_path):
     im=Image.open(image_path)
     
     pix_val = list(im.getdata())
     #print(pix_val)
     pix_val_sliced=[]
     pix_len= len(pix_val)
     

     while pix_len>=0:
          if pix_len>=3000:
               x=slice(3000)
          
               pix_val_sliced.append(pix_val[x])
               
               pix_len= pix_len - 3000
               del pix_val[0:3000]
               
          elif 0<pix_len<3000:
               
               pix_val_sliced.append(pix_val)
               pix_len=0
               
               
               break

     pix_val_ave_total=[]


     for i in pix_val_sliced:
          pix_val_ave=[]
          arr1 = np.array(i)
          r=slice(0,len(i),3)
          index_R=arr1[r]
          result_r = np.sum(index_R)/len(i)
          pix_val_ave.append(result_r)

          
          arr2 = np.array(i)
          g=slice(1,len(i),3)
          index_G=arr2[g]
          result_g = np.sum(index_G)/len(i)
          pix_val_ave.append(result_g)

          arr3 = np.array(i)
          b=slice(2,len(i),3)
          index_B=arr3[b]
          result_b = np.sum(index_B)/len(i)
          pix_val_ave.append(result_b)

          pix_val_ave_total.append(pix_val_ave)

     

     audios = []

     for item in pix_val_ave_total:
          if 240<item[0]<250 or 195<item[0]<200:#white
               
               audios.append("white.wav")
          elif 250<item[0]<255:#ran col 1
               audios.append("brightwhite.wav")
          
          elif 220<item[0]<225:#light yellow
               audios.append("lightyellow.wav")
          

          elif 165<item[0]<170 or 200<item[0]<205:#yellow
               audios.append("yellow.wav")
               
          elif 100<item[0]<105 or 86<item[0]<91:#dark orange
               audios.append("darkorange.wav")
          elif 105<item[0]<110 or 150<item[0]<155:#ran col 2
               audios.append("darkorange-5.wav")
          elif 110<item[0]<115:#dark yellow
               audios.append("darkyellow.wav")
               
          elif 120<item[0]<125:#light brown
               audios.append("lightbrown.wav")

          elif 125<item[0]<130:#purple
               audios.append("purple.wav")
          elif 130<item[0]<135 or 205<item[0]<210:#lilac
               audios.append("lilac1.wav")
          elif 135<item[0]<140 or 210<item[0]<215:#lilac
               audios.append("lilac2.wav")
          

          
          elif 190<item[0]<195 or 225<item[0]<230 :#blue
               audios.append("blue.wav")
          
          elif 50<item[0]<55 or 155<item[0]<160:#rand col 3
               audios.append("naveyblue-1.wav")
          elif 55<item[0]<60 or 35<item[0]<40:#navey blue
               audios.append("naveyblue.wav")
          elif 60<item[0]<65 or 160<item[0]<165:#rand col 4
               audios.append("naveyblue-3.wav")
          
          elif 65<item[0]<70:#dark pink
               audios.append("dark pink.wav")
          elif 70<item[0]<75 :#rand col 5
               audios.append("darkpink-2.wav")
          elif 115<item[0]<120 or 145<item[0]<150:#brown
               audios.append("brown.wav")
          elif 20<item[0]<25 or 40<item[0]<45:#dark red
               audios.append("darkred.wav")
          elif 25<item[0]<30 or 45<item[0]<50:#dark green
               audios.append("darkgreen.wav")
          elif 30<item[0]<35:#rand col 6
               audios.append("white.wav")
          
          elif 80<item[0]<83 or 230<item[0]<235:#green
               audios.append("green.wav")
          elif 83<item[0]<86:#dark brown
               audios.append("dark brown.wav")
          elif 15<item[0]<20:#gray
               audios.append("gray.wav")
          
          
          elif 225<item[0]<229 or 235<item[0]<240:#light pink
               audios.append("lightpink.wav")
          elif 230<item[0]<235:#light blue
               audios.append("lightblue.wav")
          
          elif 235<item[0]<240 :#ran col 7
               audios.append("lightblue-1.wav")
          elif 170<item[0]<175:#light red
               audios.append("lightred.wav")
          elif 175<item[0]<180 :#ran col 8
               audios.append("lightred-1.wav")
          elif 180<item[0]<185:#ran col 9
               audios.append("lightred-2.wav")

          elif 205<item[0]<210:#light green
               audios.append("lightgreen1.wav")
          elif 210<item[0]<215:#light green
               audios.append("lightgreen2.wav")
          
          elif 140<item[0]<145:#orange
               audios.append("orange.wav")
          
          
          elif 0<item[0]<15: #black
               audios.append("black.wav")

          else:
               audios.append("naveyblue-1.wav")
          
     outfile = "final_sound.wav"

     data= []
     for infile in audios:
          w = wave.open(infile, 'rb')
          data.append( [w.getparams(), w.readframes(w.getnframes())] )
          w.close()
     
     output = wave.open(outfile, 'wb')
     output.setparams(data[0][0])
     for i in range(len(data)):
          output.writeframesraw(data[i][1])
     output.close()
     winsound.PlaySound('final_sound.wav',winsound.SND_FILENAME)
     

def graph(image_path):
     a=[]
     a.append(os.path.basename(image_path))
     img=cv2.imread(a[0])
     color=('b','g','r')
     
     for i,col in enumerate(color):
          channel= img[:,:,i]
          plt.hist(channel.ravel(),256,[0,255],color=col)
    

     plt.xlim([0,255]) 
     plt.show()

