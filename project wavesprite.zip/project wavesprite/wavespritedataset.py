import pandas as pd
import numpy as np

nested_list=[

    ['White','#f4f6f7' ,240, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,241, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,242, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,243, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,244, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,245, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,246, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,247, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,248, 'Energetic', 'white.wav'],
    ['White','#f4f6f7' ,249, 'Energetic', 'white.wav'],
    
    ['Light yellow','#fcff86', 220, 'Happiness', 'lightyellow.wav'],
    ['Light yellow','#fcff86', 221, 'Happiness', 'lightyellow.wav'],
    ['Light yellow','#fcff86', 222, 'Happiness', 'lightyellow.wav'],
    ['Light yellow','#fcff86', 223, 'Happiness', 'lightyellow.wav'],
    ['Light yellow','#fcff86', 224, 'Happiness', 'lightyellow.wav'],

    ['Bright white','#ffffff', 250, 'clean', 'brightwhite.wav'], #rancol1
    ['Bright white','#ffffff', 251, 'clean', 'brightwhite.wav'], #rancol1
    ['Bright white','#ffffff', 252, 'clean', 'brightwhite.wav'], #rancol1
    ['Bright white','#ffffff', 253, 'clean', 'brightwhite.wav'], #rancol1
    ['Bright white','#ffffff', 254, 'clean', 'brightwhite.wav'], #rancol1

    ['Dark yellow', '#EEC602',110, 'Warmth', 'darkyellow.wav'],
    ['Dark yellow', '#EEC602',111, 'Warmth', 'darkyellow.wav'],
    ['Dark yellow', '#EEC602',112, 'Warmth', 'darkyellow.wav'],
    ['Dark yellow', '#EEC602',113, 'Warmth', 'darkyellow.wav'],
    ['Dark yellow', '#EEC602',114, 'Warmth', 'darkyellow.wav'],
    

    ['Yellow', '#FDEC00',165, 'Cheer', 'yellow.wav'],
    ['Yellow', '#FDEC00',166, 'Cheer', 'yellow.wav'],
    ['Yellow', '#FDEC00',167, 'Cheer', 'yellow.wav'],
    ['Yellow', '#FDEC00',168, 'Cheer', 'yellow.wav'],
    ['Yellow', '#FDEC00',169, 'Cheer', 'yellow.wav'],

    ['Dark orange','#FA8F01' ,100, 'Confidence', 'darkorange.wav'],
    ['Dark orange','#FA8F01' ,101, 'Confidence', 'darkorange.wav'],
    ['Dark orange','#FA8F01' ,102, 'Confidence', 'darkorange.wav'],
    ['Dark orange','#FA8F01' ,103, 'Confidence', 'darkorange.wav'],
    ['Dark orange','#FA8F01' ,104, 'Confidence', 'darkorange.wav'],
   

    ['Dark orange-5','#E85300' ,105, 'success', 'darkorange-5.wav'],#rancol2
    ['Dark orange-5','#E85300' ,106, 'success', 'darkorange-5.wav'],#rancol2
    ['Dark orange-5','#E85300' ,107, 'success', 'darkorange-5.wav'],#rancol2
    ['Dark orange-5','#E85300' ,108, 'success', 'darkorange-5.wav'],#rancol2
    ['Dark orange-5','#E85300' ,109, 'success', 'darkorange-5.wav'],#rancol2
    
    ['Light brown','#D1B091' ,120, 'simple', 'lightbrown.wav'],
    ['Light brown','#D1B091' ,121, 'simple', 'lightbrown.wav'],
    ['Light brown','#D1B091' ,122, 'simple', 'lightbrown.wav'],
    ['Light brown','#D1B091' ,123, 'simple', 'lightbrown.wav'],
    ['Light brown','#D1B091' ,124, 'simple', 'lightbrown.wav'],


    ['purple','#9312AC' ,125, 'Royality', 'purple.wav'],
    ['purple','#9312AC' ,126, 'Royality', 'purple.wav'],
    ['purple','#9312AC' ,127, 'Royality', 'purple.wav'],
    ['purple','#9312AC' ,128, 'Royality', 'purple.wav'],
    ['purple','#9312AC' ,129, 'Royality', 'purple.wav'],


    ['lilac','#D291D6' ,130, 'luxury', 'lilac1.wav'],
    ['lilac','#D291D6' ,131, 'luxury', 'lilac1.wav'],
    ['lilac','#D291D6' ,132, 'luxury', 'lilac1.wav'],
    ['lilac','#D291D6' ,133, 'luxury', 'lilac1.wav'],
    ['lilac','#D291D6' ,134, 'luxury', 'lilac1.wav'],

    ['lilac-2', '#EBC7ED',135, 'Ambition', 'lilac2.wav'],
    ['lilac-2', '#EBC7ED',136, 'Ambition', 'lilac2.wav'],
    ['lilac-2', '#EBC7ED',137, 'Ambition', 'lilac2.wav'],
    ['lilac-2', '#EBC7ED',138, 'Ambition', 'lilac2.wav'],
    ['lilac-2', '#EBC7ED',139, 'Ambition', 'lilac2.wav'],

    ['blue','#60B3F7' ,190 , 'Trust', 'blue.wav'],
    ['blue','#60B3F7' ,191 , 'Trust', 'blue.wav'],
    ['blue','#60B3F7' ,192 , 'Trust', 'blue.wav'],
    ['blue','#60B3F7' ,193 , 'Trust', 'blue.wav'],
    ['blue','#60B3F7' ,194 , 'Trust', 'blue.wav'],


    ['navey blue-1','#3A5D9D', 50 , 'competence', 'naveyblue-1.wav'], #rancol3
    ['navey blue-1','#3A5D9D', 51 , 'competence', 'naveyblue-1.wav'], #rancol3
    ['navey blue-1','#3A5D9D', 52 , 'competence', 'naveyblue-1.wav'], #rancol3
    ['navey blue-1','#3A5D9D', 53 , 'competence', 'naveyblue-1.wav'], #rancol3
    ['navey blue-1','#3A5D9D', 54 , 'competence', 'naveyblue-1.wav'], #rancol3

    ['navey blue','#3949AB' ,55 , 'peace', 'naveyblue.wav'],
    ['navey blue','#3949AB' ,56 , 'peace', 'naveyblue.wav'],
    ['navey blue','#3949AB' ,57 , 'peace', 'naveyblue.wav'],
    ['navey blue','#3949AB' ,58 , 'peace', 'naveyblue.wav'],
    ['navey blue','#3949AB' ,59 , 'peace', 'naveyblue.wav'],

    ['navey blue-3','#303F9F' ,60 , 'loyality', 'naveyblue-3.wav'], #rancol4
    ['navey blue-3','#303F9F' ,61, 'loyality', 'naveyblue-3.wav'], #rancol4
    ['navey blue-3','#303F9F' ,62 , 'loyality', 'naveyblue-3.wav'], #rancol4
    ['navey blue-3','#303F9F' ,63 , 'loyality', 'naveyblue-3.wav'], #rancol4
    ['navey blue-3','#303F9F' ,64 , 'loyality', 'naveyblue-3.wav'], #rancol4

    ['Dark pink','#AE4540' ,65 , 'sophistication', 'dark pink.wav'],
    ['Dark pink','#AE4540' ,66 , 'sophistication', 'dark pink.wav'],
    ['Dark pink','#AE4540' ,67 , 'sophistication', 'dark pink.wav'],
    ['Dark pink','#AE4540' ,68, 'sophistication', 'dark pink.wav'],
    ['Dark pink','#AE4540' ,69 , 'sophistication', 'dark pink.wav'],

    ['Dark pink-2','#E53731' ,70 , 'sincerity', 'darkpink-2.wav'],#rancol5
    ['Dark pink-2','#E53731' ,71 , 'sincerity', 'darkpink-2.wav'],#rancol5
    ['Dark pink-2','#E53731' ,72 , 'sincerity', 'darkpink-2.wav'],#rancol5
    ['Dark pink-2','#E53731' ,73 , 'sincerity', 'darkpink-2.wav'],#rancol5
    ['Dark pink-2','#E53731' ,74 , 'sincerity', 'darkpink-2.wav'],#rancol5
    

    ['Brown','#9A4C0L' ,115, 'rugged', 'brown.wav'],
    ['Brown','#9A4C0L' ,116, 'rugged', 'brown.wav'],
    ['Brown','#9A4C0L' ,117, 'rugged', 'brown.wav'],
    ['Brown','#9A4C0L' ,118, 'rugged', 'brown.wav'],
    ['Brown','#9A4C0L' ,119, 'rugged', 'brown.wav'],

    ['dark red', '#8B0000',20, 'exciment', 'darkred.wav'],
    ['dark red', '#8B0000',21, 'exciment', 'darkred.wav'],
    ['dark red', '#8B0000',22, 'exciment', 'darkred.wav'],
    ['dark red', '#8B0000',23, 'exciment', 'darkred.wav'],
    ['dark red', '#8B0000',24, 'exciment', 'darkred.wav'],


    ['dark green','#006400',25, 'freshness', 'darkgreen.wav'],
    ['dark green','#006400',26, 'freshness', 'darkgreen.wav'],
    ['dark green','#006400',27, 'freshness', 'darkgreen.wav'],
    ['dark green','#006400',28, 'freshness', 'darkgreen.wav'],
    ['dark green','#006400',29, 'freshness', 'darkgreen.wav'],

    ['dark green-1', '#008000',30, 'healing', 'white.wav'],
    ['dark green-1', '#008000',31, 'healing', 'white.wav'],
    ['dark green-1', '#008000',32, 'healing', 'white.wav'],
    ['dark green-1', '#008000',33, 'healing', 'white.wav'],
    ['dark green-1', '#008000',34, 'healing', 'white.wav'],

    ['green','#228B22' ,80, 'nature', 'green.wav'],
    ['green','#228B22' ,81, 'nature', 'green.wav'],
    ['green','#228B22' ,82, 'nature', 'green.wav'],
    

    ['dark brown','#8B4513' ,83, 'Trustworthy', 'dark brown.wav'],
    ['dark brown','#8B4513' ,84, 'Trustworthy', 'dark brown.wav'],
    ['dark brown','#8B4513' ,85, 'Trustworthy', 'dark brown.wav'],

    ['gray','#808080' ,15, 'comfort', 'gray.wav'],
    ['gray','#808080' ,16, 'comfort', 'gray.wav'],
    ['gray','#808080' ,17, 'comfort', 'gray.wav'],
    ['gray','#808080' ,18, 'comfort', 'gray.wav'],
    ['gray','#808080' ,19, 'comfort', 'gray.wav'],


    ['light pink','#FFB6C1' ,225, 'sweet', 'lightpink.wav'],
    ['light pink','#FFB6C1' ,226, 'sweet', 'lightpink.wav'],
    ['light pink','#FFB6C1' ,227, 'sweet', 'lightpink.wav'],
    ['light pink','#FFB6C1' ,228, 'sweet', 'lightpink.wav'],
    ['light pink','#FFB6C1' ,229, 'sweet', 'lightpink.wav'],
    
    ['light blue', '#4682B4',230, 'competence', 'lightblue.wav'],
    ['light blue', '#4682B4',231, 'competence', 'lightblue.wav'],
    ['light blue', '#4682B4',232, 'competence', 'lightblue.wav'],
    ['light blue', '#4682B4',233, 'competence', 'lightblue.wav'],
    ['light blue', '#4682B4',234, 'competence', 'lightblue.wav'],

    ['light blue-1','#6495ED' ,235, 'trust', 'lightblue-1.wav'], #rancol7
    ['light blue-1','#6495ED' ,236, 'trust', 'lightblue-1.wav'], #rancol7
    ['light blue-1','#6495ED' ,237, 'trust', 'lightblue-1.wav'], #rancol7
    ['light blue-1','#6495ED' ,238, 'trust', 'lightblue-1.wav'], #rancol7
    ['light blue-1','#6495ED' ,239, 'trust', 'lightblue-1.wav'], #rancol7


    ['light red','#FF0000' ,170, 'excitment', 'lightred.wav'],
    ['light red','#FF0000' ,171, 'excitment', 'lightred.wav'],
    ['light red','#FF0000' ,172, 'excitment', 'lightred.wav'],
    ['light red','#FF0000' ,173, 'excitment', 'lightred.wav'],
    ['light red','#FF0000' ,174, 'excitment', 'lightred.wav'],

    ['light red-1','#B22222' ,175, 'strength', 'lightred-1.wav'],#randcol8
    ['light red-1','#B22222' ,176, 'strength', 'lightred-1.wav'],#randcol8
    ['light red-1','#B22222' ,177, 'strength', 'lightred-1.wav'],#randcol8
    ['light red-1','#B22222' ,178, 'strength', 'lightred-1.wav'],#randcol8
    ['light red-1','#B22222' ,179, 'strength', 'lightred-1.wav'],#randcol8
   

    ['light red-2','#A52A2A' ,180, 'love', 'lightred-2.wav'],#rancol9
    ['light red-2','#A52A2A' ,181, 'love', 'lightred-2.wav'],#rancol9
    ['light red-2','#A52A2A' ,182, 'love', 'lightred-2.wav'],#rancol9
    ['light red-2','#A52A2A' ,183, 'love', 'lightred-2.wav'],#rancol9
    ['light red-2','#A52A2A' ,184, 'love', 'lightred-2.wav'],#rancol9
    

    ['light green', '#20B2AA',205, 'quality', 'lightgreen1.wav'],
    ['light green', '#20B2AA',206, 'quality', 'lightgreen1.wav'],
    ['light green', '#20B2AA',207, 'quality', 'lightgreen1.wav'],
    ['light green', '#20B2AA',208, 'quality', 'lightgreen1.wav'],
    ['light green', '#20B2AA',209, 'quality', 'lightgreen1.wav'],

    ['light green-2', '#2E8B57',210, 'healing', 'lightgreen2.wav'],
    ['light green-2', '#2E8B57',211, 'healing', 'lightgreen2.wav'],
    ['light green-2', '#2E8B57',212, 'healing', 'lightgreen2.wav'],
    ['light green-2', '#2E8B57',213, 'healing', 'lightgreen2.wav'],
    ['light green-2', '#2E8B57',214, 'healing', 'lightgreen2.wav'],

    ['orange','#FFA500' ,140, 'bravery', 'orange.wav'],
    ['orange','#FFA500' ,141, 'bravery', 'orange.wav'],
    ['orange','#FFA500' ,142, 'bravery', 'orange.wav'],
    ['orange','#FFA500' ,143, 'bravery', 'orange.wav'],
    ['orange','#FFA500' ,144, 'bravery', 'orange.wav'],

    ['black','#000000' ,0, 'formality', 'black.wav'],
    ['black','#000000' ,1, 'formality', 'black.wav'],
    ['black','#000000' ,2, 'formality', 'black.wav'],
    ['black','#000000' ,3, 'formality', 'black.wav'],
    ['black','#000000' ,4, 'formality', 'black.wav'],
    ['black','#000000' ,5, 'formality', 'black.wav'],
    ['black','#000000' ,6, 'formality', 'black.wav'],
    ['black','#000000' ,7, 'formality', 'black.wav'],
    ['black','#000000' ,8, 'formality', 'black.wav'],
    ['black','#000000' ,9, 'formality', 'black.wav'],
    ['black','#000000' ,10, 'formality', 'black.wav'],
    ['black','#000000' ,11, 'formality', 'black.wav'],
    ['black','#000000' ,12, 'formality', 'black.wav'],
    ['black','#000000' ,13, 'formality', 'black.wav'],
    ['black','#000000' ,14, 'formality', 'black.wav']]

wavesprite=pd.DataFrame(nested_list,columns=['Color', 'Hex_val','ave_pix_val', 'Mood','chord/key'])

wavesprite.to_csv('wavesprite.csv')
print(wavesprite)