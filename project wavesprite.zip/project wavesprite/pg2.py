import customtkinter
from project import *
from PIL import Image
from project import make_sound

root = customtkinter
customtkinter.set_appearance_mode("light")
customtkinter.set_default_color_theme("dark-blue")

app = customtkinter.CTk()
app.resizable(False,False)
app.geometry("500x750")
app.title("Wavesprite")

def previous_page():
    app.destroy()
    import pg1

hey=[]
audios=[]
slay=[]
def button_callback():
     hey.append(e1.get())
     open_pic()
     
     

def button_call():
    make_sound(hey[0])
    print(hey)
    

bg_image= customtkinter.CTkImage(Image.open(r"C:\Users\Tsion\Desktop\project wavesprite\the-art-of-animation.jpg"),
                                 size=(500,750))
bg_image_label = customtkinter.CTkLabel(app, image=bg_image,text ="")
bg_image_label.place(x=0, y=0)




e1 = customtkinter.CTkEntry(master= app, placeholder_text="Image entry",
                            placeholder_text_color="#FFFFFF",
                            fg_color ='transparent',
                            border_width= 1,
                            border_color="#B5998B",
                            bg_color= '#73625A',
                            width =150)
e1.place(x=180, y=50)
button_1 = customtkinter.CTkButton(master=app, 
                                   command=button_callback, text = "press to submit",
                                   textvariable=e1,
                                   fg_color='transparent',
                                   bg_color='#718A6C',
                                   hover_color= "#516862",
                                   height = 30)

progressbar = customtkinter.CTkProgressBar(master=app)
button_1.place(x=185, y=95)
button_2 = customtkinter.CTkButton(master=app, 
                                   command=button_call,text = "press to start",
                                   fg_color='transparent',
                                   bg_color='#718A6C',
                                   hover_color ="#516862",
                                   height = 30)
button_2.place(x=185, y=135)


def open_pic():
    button_image = customtkinter.CTkImage(Image.open(hey[0]),size = (200,300))
    image_button = customtkinter.CTkLabel(master=app,image=button_image, text= "")
    image_button.place(x=160, y =300)
    

app.mainloop()