import customtkinter
from PIL import Image

root = customtkinter
customtkinter.set_appearance_mode("light")
customtkinter.set_default_color_theme("dark-blue")

app = customtkinter.CTk()
app.resizable(False,False)
app.geometry("500x750")
app.title("Wavesprite")

def nextpage():
    app.destroy()
    import pg2

bg_image= customtkinter.CTkImage(Image.open(r"C:\Users\Tsion\Desktop\project wavesprite\1c6e479c-d8f0-467b-b696-ff3689185cd3.jpg"),
                                 size=(500,750))
bg_image_label = customtkinter.CTkLabel(app, image=bg_image,text ="")
bg_image_label.place(x=0, y=0)
label_1 = customtkinter.CTkLabel(master=app, font= customtkinter.CTkFont(family='Helvetica', size= 30,weight= 'bold'), justify=customtkinter.LEFT, 
                                 text="Welcome",
                                 width=100,
                                 height=10,
                                 corner_radius=20,
                                 text_color= "#E6DFD5",
                                 fg_color= "transparent",
                                 bg_color= "#9CA68D",
                                 pady= 10)
label_1.place(x =180, y=175)
button_1 = customtkinter.CTkButton(master=app, command=nextpage, 
                                   text = "press to continue",
                                   bg_color="#8E896B",
                                   fg_color = "transparent",
                                   hover_color= "344243",
                                   corner_radius=20)
button_1.place(x=181, y=240)
label_1.cget("font").configure(size=30)

app.mainloop()